# goidentity

Standard interface to holding authenticated identities and their attributes.

To get the package, execute:
```
go get gopkg.in/jcmturner/goidentity.v3
```
To import this package, add the following line to your code:
```go
import "gopkg.in/jcmturner/goidentity.v3"

```