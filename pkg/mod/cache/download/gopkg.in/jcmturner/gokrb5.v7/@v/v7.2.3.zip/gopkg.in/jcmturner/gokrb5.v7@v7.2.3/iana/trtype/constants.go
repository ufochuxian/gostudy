// Package trtype provides Transited Encoding Type assigned numbers.
package trtype

// Transited Encoding Type IDs.
const (
	DOMAIN_X500_COMPRESS int32 = 1
	//Reserved values                 All others
)
