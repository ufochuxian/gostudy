// +build windows

package proc

func dumpGoroutines() {
}
