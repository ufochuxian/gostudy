// +build !linux

package stat

func Report(string) {
}

func SetReporter(func(string)) {
}
