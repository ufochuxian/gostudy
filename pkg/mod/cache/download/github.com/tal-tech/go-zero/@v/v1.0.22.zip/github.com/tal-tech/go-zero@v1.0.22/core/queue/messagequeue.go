package queue

type MessageQueue interface {
	Start()
	Stop()
}
