package naming

type Namer interface {
	Name() string
}
