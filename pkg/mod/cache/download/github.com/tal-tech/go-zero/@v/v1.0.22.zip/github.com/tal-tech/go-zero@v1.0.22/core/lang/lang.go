package lang

var Placeholder PlaceholderType

type (
	GenericType     = interface{}
	PlaceholderType = struct{}
)
