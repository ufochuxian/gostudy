package kv

import (
	"github.com/tal-tech/go-zero/core/stores/cache"
)

type KvConf = cache.ClusterConf
