package main

import _ "github.com/tal-tech/go-zero/core/stat"

func main() {
	select {}
}
