// +build !linux

package internal

func RefreshCpu() uint64 {
	return 0
}
