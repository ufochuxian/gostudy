package svc

import "github.com/tal-tech/go-zero/zrpc"

type ServiceContext struct {
	Client zrpc.Client
}
