#!/bin/bash

hey -z 60s http://localhost:8080/heavy
