package cache

type CacheConf = ClusterConf
