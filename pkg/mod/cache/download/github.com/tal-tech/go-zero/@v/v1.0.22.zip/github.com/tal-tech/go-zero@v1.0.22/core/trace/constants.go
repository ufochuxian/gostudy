package trace

const (
	traceIdKey = "X-Trace-ID"
	spanIdKey  = "X-Span-ID"
)
