package main

import "github.com/gogf/gf/os/glog"

func Test() {
	glog.Error("This is error!")
}

func main() {
	Test()
}
