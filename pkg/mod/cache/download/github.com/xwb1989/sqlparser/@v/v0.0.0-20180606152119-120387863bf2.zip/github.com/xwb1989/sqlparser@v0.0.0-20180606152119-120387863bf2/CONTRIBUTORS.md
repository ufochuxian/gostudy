This project is originally a fork of [https://github.com/youtube/vitess](https://github.com/youtube/vitess)
Copyright Google Inc

# Contributors
Wenbin Xiao 2015
Started this project and maintained it.

Andrew Brampton 2017
Merged in multiple upstream fixes/changes.