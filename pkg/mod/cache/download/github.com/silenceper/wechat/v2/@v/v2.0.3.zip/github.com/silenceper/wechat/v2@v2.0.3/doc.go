/*
Package wechat provide wechat sdk for go

使用Golang开发的微信SDK，简单、易用。


更多信息：https://github.com/silenceper/wechat

*/
package wechat
