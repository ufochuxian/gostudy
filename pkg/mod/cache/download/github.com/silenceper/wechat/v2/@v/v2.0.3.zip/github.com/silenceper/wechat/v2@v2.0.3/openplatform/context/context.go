package context

import (
	"github.com/silenceper/wechat/v2/openplatform/config"
)

// Context struct
type Context struct {
	*config.Config
}
