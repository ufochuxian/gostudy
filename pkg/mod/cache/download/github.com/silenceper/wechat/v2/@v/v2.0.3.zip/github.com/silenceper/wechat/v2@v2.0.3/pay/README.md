# 微信支付

[官方文档](https://pay.weixin.qq.com/wiki/doc/api/index.html)

## 快速入门
