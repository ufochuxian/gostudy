# 微信公众号

[官方文档](https://developers.weixin.qq.com/doc/offiaccount/Getting_Started/Overview.html)

## 快速入门