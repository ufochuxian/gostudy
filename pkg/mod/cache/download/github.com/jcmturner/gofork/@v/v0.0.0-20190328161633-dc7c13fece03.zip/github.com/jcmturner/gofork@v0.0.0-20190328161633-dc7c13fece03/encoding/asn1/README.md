This is a temporary repository that will be removed when the issues below are fixed in the core golang code.

## Issues
* [encoding/asn1: cannot marshal into a GeneralString](https://github.com/golang/go/issues/18832)
* [encoding/asn1: cannot marshal into slice of strings and pass stringtype parameter tags to members](https://github.com/golang/go/issues/18834)